#import RollCallSystem as r

class Class:

    #Implement the code for a class here.

    def __init__(self):
        return

class Student:

    #Implement the code for a Student here.

    def __init__(self):
        return


def main():

    # -- YOUR CODE HERE -- #

    # -- Write your code above this point -- #
    #rcs = r.RollCallSystem()

    return

main()

